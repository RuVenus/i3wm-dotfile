#!/bin/bash
#
#
#


feh --bg-fill --randomize ~/.config/i3/wallpapers/*

