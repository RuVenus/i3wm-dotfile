#!/bin/bash
#

polybar -c ~/.config/i3/conf/polybar/config.ini 
